# Guwahati Brahmaputra Forecasting Dataset — Option C

## Purpose and status

This package contains **real web-sourced hourly weather and rainfall data** for Guwahati, Assam, prepared for a future Brahmaputra river-level forecasting model. It covers each monsoon season from **1 June through 30 September** in **2021–2025** and retains a 72-hour lead-in plus a 24-hour lead-out in the raw data to support lag and target construction.

> **This is an Option C package, not a completed river-level forecasting training set.** No authorized historical river-level record for the **Brahmaputra at Guwahati D.C. Court** was acquired. Therefore, every river-level lag and each `target_river_level_t_plus_6h_m` / `target_river_level_t_plus_24h_m` field is deliberately blank. No river level was fabricated, estimated, interpolated, or substituted.

The Assam Water Resources Department identifies Guwahati D.C. Court as a Brahmaputra gauge in Kamrup, with a listed danger level of 49.68 m and historical highest flood level of 51.46 m. These values are reference metadata only and are **not** inserted into the training CSV. [1]

## Package structure

| Path | Contents | Temporal resolution | Data status |
| :--- | :--- | :--- | :--- |
| `raw/open_meteo_era5/*.json` | Unmodified annual API responses. | Hourly | Source reanalysis. |
| `raw/guwahati_hourly_weather_rainfall_era5.csv` | Consolidated weather/rainfall source data, including padding context. | Hourly | Source reanalysis; river level unavailable. |
| `raw/authorized_guwahati_dc_court_gauge_template.csv` | Empty schema for a future authorized gauge-data upload. | Hourly/sub-daily expected | Template only. |
| `features/guwahati_weather_feature_matrix_option_c.csv` | Monsoon-period feature matrix with derived rainfall lags and accumulations. | Hourly | Weather features usable; river lags and targets intentionally unavailable. |
| `metadata/data_dictionary.csv` | Field definitions, units, provenance, and availability. | — | Documentation. |
| `metadata/file_manifest.csv` | File-level lineage and dataset role. | — | Documentation. |
| `metadata/missing_values_report.csv` | Column-level completeness statistics. | — | Documentation. |
| `scripts/fetch_open_meteo_weather.sh` | Reproducible source-data downloader. | — | Reproduction script. |
| `scripts/build_option_c_package.py` | Reproducible feature-generation workflow. | — | Transformation script. |

## Source and location

The weather and rainfall variables were retrieved through the [Open-Meteo Historical Weather API](https://open-meteo.com/en/docs/historical-weather-api) using the **ECMWF ERA5** model, requested at **26.1445° N, 91.7362° E** with local timestamps in `Asia/Kolkata` (UTC+05:30). The source API returned a grid location of **26.115992° N, 91.77437° E** and elevation of **52 m**. Consequently, the data are spatially referenced **reanalysis grid-cell values**, not direct observations from a named ground weather station. [2]

| Source property | Value |
| :--- | :--- |
| Weather/rainfall source | Open-Meteo Historical Weather API using ECMWF ERA5 |
| Requested location | 26.1445° N, 91.7362° E, Guwahati, Assam |
| Returned source grid | 26.115992° N, 91.77437° E |
| Timezone | `Asia/Kolkata` (UTC+05:30) |
| Raw coverage | 29 May–1 October for each year 2021–2025 |
| Feature coverage | 1 June–30 September for each year 2021–2025 |
| Raw rows | 15,120 hourly records |
| Feature rows | 14,640 hourly records |

## Variables and units

| Field family | Unit | Status | Meaning |
| :--- | :--- | :--- | :--- |
| `rainfall_1h_mm` | mm | Source reanalysis | Precipitation accumulated during the preceding hour. |
| `rainfall_lag_*h_mm` | mm | Derived | Whole-hour lag of the source rainfall value. |
| `rainfall_cumulative_3h_mm` to `rainfall_cumulative_72h_mm` | mm | Derived | Rolling rainfall sum ending at the row timestamp, including the current hour. |
| `temperature_2m_c` | °C | Source reanalysis | Air temperature at 2 m. |
| `relative_humidity_2m_pct` | % | Source reanalysis | Relative humidity at 2 m. |
| `pressure_msl_hpa` | hPa | Source reanalysis | Mean sea-level pressure. |
| `wind_speed_10m_ms` | m/s | Source reanalysis | Wind speed at 10 m. |
| `river_level_m_observed` | m | **Unavailable** | Must be supplied from an authorized Guwahati D.C. Court gauge record. |
| `river_level_lag_*h_m` | m | **Unavailable** | Requires the authorized river-level series. |
| `target_river_level_t_plus_6h_m` | m | **Unavailable** | Requires the authorized river-level series at `timestamp + 6 hours`. |
| `target_river_level_t_plus_24h_m` | m | **Unavailable** | Requires the authorized river-level series at `timestamp + 24 hours`. |

## Missing values and quality rules

The downloaded weather/reanalysis variables have **0 missing values** across the 15,120 raw records. The raw and feature files correctly report missing river values as **100% unavailable**, rather than imputing them. Consult `metadata/missing_values_report.csv` for the full column-level report.

The feature file should **not** be used to train a river-level model until an authorized gauge series is joined. The current `row_eligible_after_authorized_river_join` field is `0` for every row by design. When a source file arrives, match timestamps in `Asia/Kolkata`, standardize river level to metres using the gauge datum documented by the provider, calculate lags only from observed values, and discard rows with missing required lags or future targets.

## Authorized gauge-data input requirements

Place the official data in the schema represented by `raw/authorized_guwahati_dc_court_gauge_template.csv`.

| Required field | Requirement |
| :--- | :--- |
| `timestamp` | Timestamp of the gauge observation in `Asia/Kolkata`; hourly or sub-daily resolution is required for a genuine 6-hour target. |
| `river_level_m` | Measured water level in metres, retaining the agency's gauge datum. |
| `station_name` | `Guwahati D.C. Court` or the provider's official station name. |
| `observation_source` | CWC, ASDMA, Assam Water Resources, or another authorized source. |
| `source_record_id` | Original report/file/row identifier for traceability. |
| `source_unit` | Unit reported by source; convert only with documented authority. |
| `qa_flag` | Any provider quality code or a documented review status. |

Do not replace the missing river levels with satellite altimetry, flood thresholds, other gauges, daily summaries, or model estimates when building a 6-hour forecast target. Public satellite-altimetry data have revisit intervals measured in days, not hours, and cannot serve as an equivalent short-horizon stage series. [3]

## Reproduction

From this directory, run the downloader and then the builder:

```bash
bash scripts/fetch_open_meteo_weather.sh
python3 scripts/build_option_c_package.py
```

## References

[1] [Government of Assam, Water Resources Department — Flood Information System](https://waterresources.assam.gov.in/portlets/flood-information-system)  
[2] [Open-Meteo — Historical Weather API documentation](https://open-meteo.com/en/docs/historical-weather-api)  
[3] [Theia Hydroweb — Water levels of rivers and lakes](https://www.theia-land.fr/en/blog/product/water-levels-of-rivers-and-lakes-hydroweb/)
