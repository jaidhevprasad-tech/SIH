#!/usr/bin/env python3
"""Build the Guwahati Option C weather/rainfall package from real Open-Meteo ERA5 files.

No river-level data are fabricated, estimated, or substituted. River fields in the
feature matrix are explicitly retained as unavailable so a later authorized gauge
file can be joined without changing the feature schema.
"""
from __future__ import annotations

import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW_JSON_DIR = ROOT / "raw" / "open_meteo_era5"
RAW_OUT = ROOT / "raw" / "guwahati_hourly_weather_rainfall_era5.csv"
FEATURE_OUT = ROOT / "features" / "guwahati_weather_feature_matrix_option_c.csv"
METADATA_DIR = ROOT / "metadata"

for directory in (RAW_OUT.parent, FEATURE_OUT.parent, METADATA_DIR):
    directory.mkdir(parents=True, exist_ok=True)

records: list[pd.DataFrame] = []
for path in sorted(RAW_JSON_DIR.glob("guwahati_era5_hourly_*.json")):
    payload = json.loads(path.read_text())
    hourly = payload["hourly"]
    frame = pd.DataFrame(hourly)
    frame["requested_latitude"] = 26.1445
    frame["requested_longitude"] = 91.7362
    frame["source_grid_latitude"] = payload["latitude"]
    frame["source_grid_longitude"] = payload["longitude"]
    frame["source_elevation_m"] = payload["elevation"]
    frame["timezone"] = payload["timezone"]
    frame["weather_source"] = "Open-Meteo Historical Weather API; ECMWF ERA5"
    frame["weather_source_url"] = "https://archive-api.open-meteo.com/v1/archive"
    frame["weather_model"] = "era5"
    records.append(frame)

if len(records) != 5:
    raise RuntimeError(f"Expected five annual source files; found {len(records)}")

raw = pd.concat(records, ignore_index=True)
raw = raw.rename(columns={
    "time": "timestamp",
    "temperature_2m": "temperature_2m_c",
    "relative_humidity_2m": "relative_humidity_2m_pct",
    "pressure_msl": "pressure_msl_hpa",
    "wind_speed_10m": "wind_speed_10m_ms",
    "precipitation": "rainfall_1h_mm",
})
raw["timestamp"] = pd.to_datetime(raw["timestamp"])
raw = raw.sort_values("timestamp").drop_duplicates("timestamp", keep="last").reset_index(drop=True)
raw["is_target_monsoon_period"] = (
    raw["timestamp"].dt.month.isin([6, 7, 8, 9])
).astype("int8")
raw["is_lag_context_padding"] = (1 - raw["is_target_monsoon_period"]).astype("int8")
raw["weather_missing_any"] = raw[[
    "temperature_2m_c", "relative_humidity_2m_pct", "pressure_msl_hpa",
    "wind_speed_10m_ms", "rainfall_1h_mm",
]].isna().any(axis=1).astype("int8")
raw["river_level_m_observed"] = pd.NA
raw["river_data_status"] = "unavailable_authorized_series_not_acquired"
raw.to_csv(RAW_OUT, index=False, date_format="%Y-%m-%dT%H:%M:%S")

features = raw.copy()
features["year"] = features["timestamp"].dt.year
features["month"] = features["timestamp"].dt.month
features["day"] = features["timestamp"].dt.day
features["hour"] = features["timestamp"].dt.hour

for hours in (1, 3, 6, 12, 24, 72):
    features[f"rainfall_lag_{hours}h_mm"] = features["rainfall_1h_mm"].shift(hours)
    features[f"rainfall_cumulative_{hours}h_mm"] = features["rainfall_1h_mm"].rolling(hours, min_periods=hours).sum()

for hours in (1, 3, 6, 12, 24):
    features[f"river_level_lag_{hours}h_m"] = pd.NA
for hours in (6, 24):
    features[f"target_river_level_t_plus_{hours}h_m"] = pd.NA

features["river_data_status"] = "unavailable_authorized_series_not_acquired"
features["row_eligible_after_authorized_river_join"] = 0
features = features.loc[features["is_target_monsoon_period"].eq(1)].copy()

feature_columns = [
    "timestamp", "timezone", "year", "month", "day", "hour",
    "rainfall_1h_mm", "rainfall_lag_1h_mm", "rainfall_lag_3h_mm",
    "rainfall_lag_6h_mm", "rainfall_lag_12h_mm", "rainfall_lag_24h_mm",
    "rainfall_lag_72h_mm", "rainfall_cumulative_3h_mm",
    "rainfall_cumulative_6h_mm", "rainfall_cumulative_12h_mm",
    "rainfall_cumulative_24h_mm", "rainfall_cumulative_72h_mm",
    "temperature_2m_c", "relative_humidity_2m_pct", "pressure_msl_hpa",
    "wind_speed_10m_ms", "river_level_m_observed", "river_level_lag_1h_m",
    "river_level_lag_3h_m", "river_level_lag_6h_m", "river_level_lag_12h_m",
    "river_level_lag_24h_m", "target_river_level_t_plus_6h_m",
    "target_river_level_t_plus_24h_m", "river_data_status",
    "row_eligible_after_authorized_river_join", "weather_missing_any",
    "weather_source", "weather_model", "source_grid_latitude", "source_grid_longitude",
]
features = features[feature_columns]
features.to_csv(FEATURE_OUT, index=False, date_format="%Y-%m-%dT%H:%M:%S")

# Dataset-specific missing-value report.
report_rows = []
for name, series in raw.items():
    report_rows.append({
        "file": RAW_OUT.name,
        "column": name,
        "rows": len(raw),
        "missing_count": int(series.isna().sum()),
        "missing_percent": round(float(series.isna().mean() * 100), 4),
    })
for name, series in features.items():
    report_rows.append({
        "file": FEATURE_OUT.name,
        "column": name,
        "rows": len(features),
        "missing_count": int(series.isna().sum()),
        "missing_percent": round(float(series.isna().mean() * 100), 4),
    })
pd.DataFrame(report_rows).to_csv(METADATA_DIR / "missing_values_report.csv", index=False)

# File-level manifest that distinguishes observed, derived, and unavailable fields.
manifest = pd.DataFrame([
    {
        "file": "raw/guwahati_hourly_weather_rainfall_era5.csv",
        "role": "raw_weather_rainfall",
        "rows": len(raw),
        "temporal_resolution": "hourly",
        "period_including_padding": f"{raw['timestamp'].min():%Y-%m-%d %H:%M} to {raw['timestamp'].max():%Y-%m-%d %H:%M}",
        "observed_or_derived": "source reanalysis values supplied by Open-Meteo/ECMWF ERA5; not direct station observations; no river observations included",
        "river_level_status": "not acquired",
    },
    {
        "file": "features/guwahati_weather_feature_matrix_option_c.csv",
        "role": "weather_feature_matrix",
        "rows": len(features),
        "temporal_resolution": "hourly",
        "period_including_padding": f"{features['timestamp'].min():%Y-%m-%d %H:%M} to {features['timestamp'].max():%Y-%m-%d %H:%M}",
        "observed_or_derived": "weather fields copied from source reanalysis; rainfall lags and cumulative features are derived",
        "river_level_status": "not acquired; river lags and targets intentionally blank",
    },
])
manifest.to_csv(METADATA_DIR / "file_manifest.csv", index=False)

# Schema for an authorized gauge upload.
gauge_template = pd.DataFrame(columns=[
    "timestamp", "river_level_m", "station_name", "observation_source",
    "source_record_id", "source_unit", "qa_flag"
])
gauge_template.to_csv(ROOT / "raw" / "authorized_guwahati_dc_court_gauge_template.csv", index=False)

# Data dictionary.
dictionary_rows = [
    ["timestamp", "datetime", "Source-reanalysis timestamp in Asia/Kolkata", "Open-Meteo Historical Weather API / ECMWF ERA5", "source_reanalysis_metadata"],
    ["rainfall_1h_mm", "mm", "Preceding one-hour precipitation", "Open-Meteo Historical Weather API / ECMWF ERA5", "source_reanalysis"],
    ["rainfall_lag_*h_mm", "mm", "Rainfall value at the indicated whole-hour lag", "Derived from rainfall_1h_mm", "derived"],
    ["rainfall_cumulative_*h_mm", "mm", "Rolling rainfall sum ending at timestamp; includes current hourly value", "Derived from rainfall_1h_mm", "derived"],
    ["temperature_2m_c", "degC", "Air temperature at 2 m", "Open-Meteo Historical Weather API / ECMWF ERA5", "source_reanalysis"],
    ["relative_humidity_2m_pct", "percent", "Relative humidity at 2 m", "Open-Meteo Historical Weather API / ECMWF ERA5", "source_reanalysis"],
    ["pressure_msl_hpa", "hPa", "Mean sea-level pressure", "Open-Meteo Historical Weather API / ECMWF ERA5", "source_reanalysis"],
    ["wind_speed_10m_ms", "m/s", "Wind speed at 10 m", "Open-Meteo Historical Weather API / ECMWF ERA5", "source_reanalysis"],
    ["river_level_m_observed", "m", "Authorized gauge water level", "Not acquired", "unavailable"],
    ["river_level_lag_*h_m", "m", "Whole-hour river-level lag", "Requires authorized river_level_m_observed", "unavailable"],
    ["target_river_level_t_plus_6h_m", "m", "River level six hours after timestamp", "Requires authorized river_level_m_observed", "unavailable"],
    ["target_river_level_t_plus_24h_m", "m", "River level 24 hours after timestamp", "Requires authorized river_level_m_observed", "unavailable"],
]
pd.DataFrame(dictionary_rows, columns=["field_or_pattern", "unit", "definition", "provenance", "status"]).to_csv(
    METADATA_DIR / "data_dictionary.csv", index=False
)

print(f"Raw rows: {len(raw)}")
print(f"Feature rows: {len(features)}")
print(f"Raw output: {RAW_OUT}")
print(f"Feature output: {FEATURE_OUT}")
