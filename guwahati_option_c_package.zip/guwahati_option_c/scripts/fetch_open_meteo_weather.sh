#!/usr/bin/env bash
# Download real hourly reanalysis weather observations for Guwahati, Assam.
# Source: Open-Meteo Historical Weather API, model=era5.
# The range includes a 72-hour lead-in and 24-hour lead-out around each monsoon season.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT_DIR="$ROOT/raw/open_meteo_era5"
mkdir -p "$OUT_DIR"

LATITUDE="26.1445"
LONGITUDE="91.7362"
VARS="temperature_2m,relative_humidity_2m,pressure_msl,wind_speed_10m,precipitation"

for YEAR in 2021 2022 2023 2024 2025; do
  START="${YEAR}-05-29"
  END="${YEAR}-10-01"
  OUT="$OUT_DIR/guwahati_era5_hourly_${YEAR}.json"
  TMP="$OUT.tmp"
  URL="https://archive-api.open-meteo.com/v1/archive?latitude=${LATITUDE}&longitude=${LONGITUDE}&start_date=${START}&end_date=${END}&hourly=${VARS}&timezone=Asia%2FKolkata&wind_speed_unit=ms&models=era5"

  rm -f "$TMP"
  curl --fail --silent --show-error --retry 8 --retry-all-errors --retry-delay 3 "$URL" -o "$TMP"
  grep -q '"hourly"' "$TMP"
  mv "$TMP" "$OUT"
  echo "Saved $OUT"
done
