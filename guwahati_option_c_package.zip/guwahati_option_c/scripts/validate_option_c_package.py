#!/usr/bin/env python3
"""Validate coverage and safety constraints for the Guwahati Option C data package."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
raw_path = ROOT / "raw" / "guwahati_hourly_weather_rainfall_era5.csv"
feature_path = ROOT / "features" / "guwahati_weather_feature_matrix_option_c.csv"

raw = pd.read_csv(raw_path, parse_dates=["timestamp"])
features = pd.read_csv(feature_path, parse_dates=["timestamp"])

assert len(raw) == 15120, f"Unexpected raw row count: {len(raw)}"
assert len(features) == 14640, f"Unexpected feature row count: {len(features)}"
assert raw["timestamp"].is_unique, "Raw timestamps are not unique"
assert features["timestamp"].is_unique, "Feature timestamps are not unique"
assert set(features["timestamp"].dt.month.unique()) == {6, 7, 8, 9}, "Feature file includes non-monsoon months"
assert set(features["timestamp"].dt.year.unique()) == {2021, 2022, 2023, 2024, 2025}, "Feature years incorrect"

weather_columns = [
    "rainfall_1h_mm", "rainfall_lag_1h_mm", "rainfall_lag_3h_mm", "rainfall_lag_6h_mm",
    "rainfall_lag_12h_mm", "rainfall_lag_24h_mm", "rainfall_lag_72h_mm",
    "rainfall_cumulative_3h_mm", "rainfall_cumulative_6h_mm", "rainfall_cumulative_12h_mm",
    "rainfall_cumulative_24h_mm", "rainfall_cumulative_72h_mm", "temperature_2m_c",
    "relative_humidity_2m_pct", "pressure_msl_hpa", "wind_speed_10m_ms",
]
assert not features[weather_columns].isna().any().any(), "Weather or rainfall features contain unexpected missing values"

river_columns = [
    "river_level_m_observed", "river_level_lag_1h_m", "river_level_lag_3h_m",
    "river_level_lag_6h_m", "river_level_lag_12h_m", "river_level_lag_24h_m",
    "target_river_level_t_plus_6h_m", "target_river_level_t_plus_24h_m",
]
assert features[river_columns].isna().all().all(), "River values were unexpectedly populated"
assert (features["river_data_status"] == "unavailable_authorized_series_not_acquired").all(), "River status is inconsistent"
assert (features["row_eligible_after_authorized_river_join"] == 0).all(), "Rows incorrectly marked eligible"

print("PASS")
print(f"raw_rows={len(raw)}")
print(f"feature_rows={len(features)}")
print(f"raw_start={raw['timestamp'].min():%Y-%m-%d %H:%M}")
print(f"raw_end={raw['timestamp'].max():%Y-%m-%d %H:%M}")
print(f"feature_start={features['timestamp'].min():%Y-%m-%d %H:%M}")
print(f"feature_end={features['timestamp'].max():%Y-%m-%d %H:%M}")
print("weather_features_missing=0")
print(f"river_feature_cells_intentionally_blank={int(features[river_columns].isna().sum().sum())}")
