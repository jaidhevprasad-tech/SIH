# Assam, India: Disaster Information Dataset Package

## Purpose

This package scopes the **Geospatial Platform for Disaster Information and Decision Support** to **Assam, India**, with flood preparedness and response as the primary use case. It provides a verified Assam area-of-interest boundary, a machine-readable dataset catalogue, a Google Earth Engine export script for dynamic satellite and rainfall data, and a PostGIS schema for the resulting operational layers.

> **Important:** Large, frequently changing raster data and operational forecasts are deliberately **not versioned in Git**. They must be obtained at run time from their authoritative providers. The small, stable `boundaries/assam_boundary.geojson` file is included to make the platform immediately usable. All downloaded datasets must retain their original source, licence, observation time, processing version, and retrieval date.

## Contents

| Path | Content | Use in the platform |
| :--- | :--- | :--- |
| `boundaries/assam_boundary.geojson` | Assam administrative boundary in WGS 84 (EPSG:4326), obtained from OpenStreetMap Nominatim | Area of interest for filtering, clipping, and dashboard zoom extent. |
| `metadata/dataset_catalog.csv` | Dataset inventory, sources, cadence, access mechanisms, licences, and intended tables | Source-of-truth data registry. |
| `metadata/emergency_facilities_template.csv` | Validated input schema for relief camps, shelters, medical facilities, and resource depots | Local-authority data intake; it contains **no fabricated facility records**. |
| `scripts/export_assam_earth_engine.js` | Earth Engine script for exporting Assam rainfall, Sentinel-1 SAR, Sentinel-2 optical, and population layers | Satellite/weather acquisition for XGBoost, U-Net, and exposure analysis. |
| `../../database/assam_postgis.sql` | PostGIS tables, spatial indices, and exposure/risk view | GIS database and Risk Engine. |

## Dataset-to-Architecture Mapping

| Architecture input | Assam / India dataset | Primary variables | Model or service | Refresh strategy |
| :--- | :--- | :--- | :--- | :--- |
| **Rainfall** | NASA GPM IMERG V07 | Half-hourly calibrated precipitation (`precipitation`, mm/hr) | XGBoost rainfall-lag and accumulation features | Fetch every 30 minutes; aggregate to 1 h, 24 h, 48 h, and 72 h. |
| **River level and forecast** | Central Water Commission (CWC) Flood Forecast / India-WRIS | Observed water level, warning level, danger level, forecast category and forecast level | XGBoost prediction target and Hazard Score | Refresh at least every 3 hours during the flood season; store each observation with station/time provenance. |
| **Flood extent** | Sentinel-1 GRD (SAR) | VV, VH, incidence angle, acquisition time, orbit direction | U-Net segmentation and flood extent vectors | Search each new compatible pass. Prefer like-for-like pre-/post-event orbit and polarization. |
| **Optical context and validation** | Sentinel-2 SR Harmonized | B2, B3, B4, B8, B11, B12, cloud/classification bands | U-Net validation, NDWI/MNDWI, land-cover and damage context | Fetch the least-cloudy scenes within the event window. |
| **Flood susceptibility** | ASDMA Flood Hazard Atlas and NDEM/NRSC Bhuvan disaster services | Historic hazard zones and event flood-map products | Static Hazard Score baseline and model validation | Load published source layers after licence and access validation; update when a new atlas/version is issued. |
| **Roads and buildings** | OpenStreetMap via Geofabrik or Overpass API | Roads, bridges, buildings, amenity tags, access restrictions | PostGIS exposure analysis and pgRouting evacuation routing | Nightly or weekly incremental refresh; validate critical infrastructure with official data. |
| **Population exposure** | WorldPop 100 m population | Population count per grid cell | Exposure Score and affected-population estimates | Use a documented base year; do not mix population vintages in one risk run. |
| **Shelters and resources** | ASDMA / district administration / relief-camp lists | Facility name, type, capacity, status, contact, location and last verification time | Shelter selection and resource allocation | Update through an authorized local source before operational deployment. The provided file is a schema only. |

## Official and Authoritative Sources

| Dataset / service | Authority | Access route | Notes |
| :--- | :--- | :--- | :--- |
| GPM IMERG V07 | NASA GES DISC | [Earth Engine catalogue](https://developers.google.com/earth-engine/datasets/catalog/NASA_GPM_L3_IMERG_V07) or NASA Earthdata | Provides global half-hourly precipitation estimates. NASA data are freely available for public use. [1] |
| CWC Flood Forecasting | Central Water Commission, Government of India | [Flood Forecast portal](https://ffs.india-water.gov.in/main/site) and [CWC hydrological observation page](https://www.cwc.gov.in/flood-forecasting-hydrological-observation) | CWC operates national flood monitoring/forecasting across the Brahmaputra and Barak systems; the government source lists **25 level forecasting stations in Assam**. [2] [3] |
| Sentinel-1 GRD | ESA/Copernicus | [Earth Engine catalogue](https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S1_GRD) or Copernicus Data Space | Calibrated and terrain-corrected SAR; all-weather capability is valuable during monsoon cloud cover. [4] |
| Sentinel-2 SR Harmonized | ESA/Copernicus | [Earth Engine catalogue](https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2_SR_HARMONIZED) or Copernicus Data Space | Ten-metre optical bands are used for water/land-cover context when cloud-free. [5] |
| Assam Flood Hazard Atlas | ASDMA | [ASDMA Flood Hazard Atlas](https://asdma.gov.in/flood_hazard.html) | ASDMA publishes state-level and district-wise atlas resources. Obtain/use according to portal terms and retain the publication year. [6] |
| NDEM / Bhuvan disaster maps | NRSC/ISRO | [Bhuvan Disaster Services](https://bhuvan-app1.nrsc.gov.in/disaster/disaster.php) | National disaster geoportal; access/usage conditions should be reviewed before automated or production use. [7] |
| Assam urban GIS layers | Directorate of Town and Country Planning, Government of Assam | [GIS GeoHUB Assam](https://gistcp.assam.gov.in/) | The portal provides urban GIS maps/datasets. Respect access, copyright, and non-commercial conditions for LiDAR and other restricted layers. [8] |
| Population | WorldPop | [Earth Engine catalogue](https://developers.google.com/earth-engine/datasets/catalog/WorldPop_GP_100m_pop) | Approx. 100 m grid; use with clear WorldPop attribution (CC BY 4.0). [9] |
| Administrative boundary | OpenStreetMap contributors | Included file; Nominatim search service | ODbL 1.0 attribution is embedded in the GeoJSON. For statutory boundaries, verify with the appropriate Government of Assam source. [10] |

## Data Governance Rules

The dashboard must display the **source name, observed/issued time in IST and UTC, data quality/status, and last refresh time** for every weather, river, and hazard layer. CWC observations and forecasts should be treated as the authoritative operational source for river conditions; global model products such as GloFAS are complementary context, not a replacement for local authority bulletins.

Store Sentinel source scenes and U-Net output separately. Each `flood_extents` record needs the model version, inference timestamp, source-scene identifiers, threshold or probability, and analyst approval status. This makes flood maps traceable and prevents unreviewed model outputs from being used as final emergency instructions.

Do not publish personally identifiable information, live vulnerable-person locations, unverified shelter capacity, or operational security-sensitive data. Shelter and relief-centre records must come from an authorized authority and be verified immediately before displaying them as active in the dashboard.

## Quick Start

First, create a PostGIS database with the PostGIS extension, then run `database/assam_postgis.sql`. Load the Assam boundary as the first `admin_boundaries` row. Use the Earth Engine script to export raster data for selected dates. Finally, use an authorized CWC/ASDMA/India-WRIS feed or verified download to populate river gauges and emergency facilities.

```bash
createdb arthi_disaster
psql -d arthi_disaster -c 'CREATE EXTENSION IF NOT EXISTS postgis;'
psql -d arthi_disaster -f database/assam_postgis.sql

# Example: load the included boundary with GDAL/OGR.
ogr2ogr -f PostgreSQL PG:'dbname=arthi_disaster' \
  data/assam/boundaries/assam_osm_boundary.geojson \
  -nln staging_assam_boundary -nlt MULTIPOLYGON -lco GEOMETRY_NAME=geom
```

## References

[1] [NASA GPM IMERG V07 data catalogue](https://developers.google.com/earth-engine/datasets/catalog/NASA_GPM_L3_IMERG_V07)  
[2] [Central Water Commission, Flood Forecasting & Hydrological Observation](https://www.cwc.gov.in/flood-forecasting-hydrological-observation)  
[3] [Ministry of Jal Shakti, Flood Forecasting network](https://www.jalshakti-dowr.gov.in/offerings/schemes-and-services/details/flood-forecasting-gNwETNtQWa)  
[4] [Copernicus Sentinel-1 GRD catalogue](https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S1_GRD)  
[5] [Copernicus Sentinel-2 SR Harmonized catalogue](https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2_SR_HARMONIZED)  
[6] [Assam State Disaster Management Authority, Flood Hazard Atlas](https://asdma.gov.in/flood_hazard.html)  
[7] [NRSC/ISRO Bhuvan Disaster Services](https://bhuvan-app1.nrsc.gov.in/disaster/disaster.php)  
[8] [GIS GeoHUB, Town and Country Planning, Assam](https://gistcp.assam.gov.in/)  
[9] [WorldPop Global Project Population Data](https://developers.google.com/earth-engine/datasets/catalog/WorldPop_GP_100m_pop)  
[10] [OpenStreetMap copyright and licence](https://www.openstreetmap.org/copyright)  

---

**Prepared for:** SIH — Geospatial Platform for Disaster Information and Decision Support  
**Scope:** Assam, India  
**Prepared on:** 12 August 2026
