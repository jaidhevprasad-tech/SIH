/*
 * Assam flood-monitoring inputs for the SIH disaster information platform.
 *
 * Run in https://code.earthengine.google.com after selecting an event window.
 * Exports are sent to Google Drive; update DRIVE_FOLDER before running.
 *
 * Sources:
 * - NASA/GPM_L3/IMERG_V07
 * - COPERNICUS/S1_GRD
 * - COPERNICUS/S2_SR_HARMONIZED
 * - WorldPop/GP/100m/pop
 * - FAO/GAUL/2015/level1
 */

var START_DATE = '2026-06-01';
var END_DATE = '2026-06-08';
var DRIVE_FOLDER = 'arthi_assam_exports';
var EXPORT_SCALE_METRES = 10;

// The local repository also contains an OSM-derived Assam boundary. The GAUL
// geometry keeps this Earth Engine script self-contained. Check any boundary
// differences before using results for statutory reporting.
var assamFeature = ee.FeatureCollection('FAO/GAUL/2015/level1')
  .filter(ee.Filter.eq('ADM0_NAME', 'India'))
  .filter(ee.Filter.eq('ADM1_NAME', 'Assam'));
var assam = assamFeature.geometry();

Map.centerObject(assam, 7);
Map.addLayer(assamFeature.style({color: 'ffd92f', fillColor: '00000000'}), {}, 'Assam AOI');

// --- 1. Rainfall features for the XGBoost forecast model -------------------
// IMERG precipitation is mm/hour for a half-hour snapshot. Multiply by 0.5
// before summing to obtain accumulated precipitation in millimetres.
var rainfall = ee.ImageCollection('NASA/GPM_L3/IMERG_V07')
  .filterDate(START_DATE, END_DATE)
  .filterBounds(assam)
  .select('precipitation');
var rainfallAccumulationMm = rainfall.map(function(image) {
  return image.multiply(0.5).copyProperties(image, image.propertyNames());
}).sum().clip(assam).rename('rainfall_accumulation_mm');

Map.addLayer(
  rainfallAccumulationMm,
  {min: 0, max: 300, palette: ['ffffff', 'b3e2cd', '66c2a5', '3288bd', '5e4fa2']},
  'IMERG accumulated rainfall (mm)'
);

Export.image.toDrive({
  image: rainfallAccumulationMm,
  description: 'assam_imerg_rainfall_' + START_DATE + '_' + END_DATE,
  folder: DRIVE_FOLDER,
  fileNamePrefix: 'assam_imerg_rainfall_' + START_DATE + '_' + END_DATE,
  region: assam,
  scale: 11132,
  crs: 'EPSG:4326',
  maxPixels: 1e13
});

// --- 2. Sentinel-1 SAR inputs for the U-Net flood extent model -------------
// Keep a single orbit direction and consistent VV/VH dual polarization for
// before/after flood comparisons. SAR supports cloud-obscured monsoon events.
var sentinel1 = ee.ImageCollection('COPERNICUS/S1_GRD')
  .filterBounds(assam)
  .filterDate(START_DATE, END_DATE)
  .filter(ee.Filter.eq('instrumentMode', 'IW'))
  .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
  .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
  .filter(ee.Filter.eq('orbitProperties_pass', 'DESCENDING'))
  .select(['VV', 'VH', 'angle']);

var s1Composite = sentinel1.median().clip(assam);
Map.addLayer(s1Composite.select('VV'), {min: -25, max: 0}, 'Sentinel-1 VV composite');

Export.image.toDrive({
  image: s1Composite,
  description: 'assam_s1_vv_vh_angle_' + START_DATE + '_' + END_DATE,
  folder: DRIVE_FOLDER,
  fileNamePrefix: 'assam_s1_vv_vh_angle_' + START_DATE + '_' + END_DATE,
  region: assam,
  scale: EXPORT_SCALE_METRES,
  crs: 'EPSG:4326',
  maxPixels: 1e13
});

// --- 3. Sentinel-2 context/validation for U-Net ----------------------------
function maskS2Clouds(image) {
  // 2024+ SCL values: 3 cloud shadow, 8/9 cloud, 10 cirrus. Keep water,
  // vegetation, soil and unclassified pixels only.
  var scl = image.select('SCL');
  var clear = scl.neq(3).and(scl.neq(8)).and(scl.neq(9)).and(scl.neq(10));
  return image.updateMask(clear).divide(10000)
    .copyProperties(image, image.propertyNames());
}

var sentinel2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
  .filterBounds(assam)
  .filterDate(START_DATE, END_DATE)
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 50))
  .map(maskS2Clouds)
  .select(['B2', 'B3', 'B4', 'B8', 'B11', 'B12']);
var s2Composite = sentinel2.median().clip(assam);
var ndwi = s2Composite.normalizedDifference(['B3', 'B8']).rename('ndwi');
Map.addLayer(s2Composite, {bands: ['B4', 'B3', 'B2'], min: 0, max: 0.3}, 'Sentinel-2 RGB composite');
Map.addLayer(ndwi, {min: -0.5, max: 0.5, palette: ['8c510a', 'f6e8c3', '01665e']}, 'Sentinel-2 NDWI');

Export.image.toDrive({
  image: s2Composite.addBands(ndwi),
  description: 'assam_s2_context_' + START_DATE + '_' + END_DATE,
  folder: DRIVE_FOLDER,
  fileNamePrefix: 'assam_s2_context_' + START_DATE + '_' + END_DATE,
  region: assam,
  scale: EXPORT_SCALE_METRES,
  crs: 'EPSG:4326',
  maxPixels: 1e13
});

// --- 4. Static population exposure layer -----------------------------------
// Use a single documented vintage in any risk-assessment run. 2021 is the
// newest year in this particular Earth Engine WorldPop collection.
var population2021 = ee.ImageCollection('WorldPop/GP/100m/pop')
  .filter(ee.Filter.eq('country', 'IND'))
  .filter(ee.Filter.eq('year', 2021))
  .first()
  .select('population')
  .clip(assam);
Map.addLayer(population2021, {min: 0, max: 100, palette: ['ffffcc', 'fd8d3c', '800026']}, 'WorldPop population 2021');

Export.image.toDrive({
  image: population2021,
  description: 'assam_worldpop_2021',
  folder: DRIVE_FOLDER,
  fileNamePrefix: 'assam_worldpop_2021',
  region: assam,
  scale: 100,
  crs: 'EPSG:4326',
  maxPixels: 1e13
});

// Export the exact AOI used by this script to aid reproducibility.
Export.table.toDrive({
  collection: assamFeature,
  description: 'assam_gaul_aoi',
  folder: DRIVE_FOLDER,
  fileNamePrefix: 'assam_gaul_aoi',
  fileFormat: 'GeoJSON'
});

print('Assam AOI', assamFeature);
print('Sentinel-1 scene count', sentinel1.size());
print('Sentinel-2 scene count', sentinel2.size());
print('IMERG half-hour image count', rainfall.size());
