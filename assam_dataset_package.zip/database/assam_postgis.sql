-- Assam, India disaster-information platform: PostGIS schema
-- Coordinate reference system: EPSG:4326 (WGS 84).
-- Run after: CREATE EXTENSION IF NOT EXISTS postgis;

BEGIN;

CREATE TABLE IF NOT EXISTS admin_boundaries (
    admin_id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    admin_level SMALLINT NOT NULL CHECK (admin_level IN (1, 2, 3)),
    source_name TEXT NOT NULL,
    source_version TEXT,
    valid_from DATE,
    geom GEOMETRY(MULTIPOLYGON, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS admin_boundaries_geom_gix ON admin_boundaries USING GIST (geom);

CREATE TABLE IF NOT EXISTS river_gauges (
    gauge_id BIGSERIAL PRIMARY KEY,
    external_station_id TEXT UNIQUE,
    station_name TEXT NOT NULL,
    river_name TEXT,
    district_name TEXT,
    warning_level_m NUMERIC(8, 3),
    danger_level_m NUMERIC(8, 3),
    highest_flood_level_m NUMERIC(8, 3),
    source_name TEXT NOT NULL DEFAULT 'CWC',
    geom GEOMETRY(POINT, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (warning_level_m IS NULL OR warning_level_m >= 0),
    CHECK (danger_level_m IS NULL OR danger_level_m >= 0),
    CHECK (highest_flood_level_m IS NULL OR highest_flood_level_m >= 0)
);
CREATE INDEX IF NOT EXISTS river_gauges_geom_gix ON river_gauges USING GIST (geom);

CREATE TABLE IF NOT EXISTS river_observations (
    observation_id BIGSERIAL PRIMARY KEY,
    gauge_id BIGINT NOT NULL REFERENCES river_gauges(gauge_id),
    observed_at TIMESTAMPTZ NOT NULL,
    water_level_m NUMERIC(8, 3),
    discharge_cumecs NUMERIC(12, 3),
    forecast_at TIMESTAMPTZ,
    forecast_water_level_m NUMERIC(8, 3),
    flood_category TEXT CHECK (flood_category IN ('normal', 'above_normal', 'severe', 'extreme', 'unknown')),
    source_url TEXT,
    source_recorded_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (gauge_id, observed_at, COALESCE(forecast_at, observed_at))
);
CREATE INDEX IF NOT EXISTS river_observations_gauge_time_ix ON river_observations (gauge_id, observed_at DESC);

CREATE TABLE IF NOT EXISTS rainfall_grids (
    rainfall_id BIGSERIAL PRIMARY KEY,
    observed_from TIMESTAMPTZ NOT NULL,
    observed_to TIMESTAMPTZ NOT NULL,
    accumulation_mm NUMERIC(10, 3) NOT NULL CHECK (accumulation_mm >= 0),
    source_name TEXT NOT NULL DEFAULT 'NASA GPM IMERG V07',
    source_status TEXT CHECK (source_status IN ('provisional', 'permanent', 'unknown')) DEFAULT 'unknown',
    source_scene_ids TEXT[],
    geom GEOMETRY(POLYGON, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (observed_to > observed_from)
);
CREATE INDEX IF NOT EXISTS rainfall_grids_geom_gix ON rainfall_grids USING GIST (geom);
CREATE INDEX IF NOT EXISTS rainfall_grids_time_ix ON rainfall_grids (observed_to DESC);

CREATE TABLE IF NOT EXISTS infrastructure_roads (
    road_id BIGSERIAL PRIMARY KEY,
    external_id TEXT,
    name TEXT,
    road_class TEXT,
    bridge BOOLEAN DEFAULT FALSE,
    access_status TEXT NOT NULL DEFAULT 'unknown' CHECK (access_status IN ('open', 'restricted', 'closed', 'unknown')),
    source_name TEXT NOT NULL DEFAULT 'OpenStreetMap',
    source_updated_at TIMESTAMPTZ,
    geom GEOMETRY(MULTILINESTRING, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS infrastructure_roads_geom_gix ON infrastructure_roads USING GIST (geom);

CREATE TABLE IF NOT EXISTS infrastructure_buildings (
    building_id BIGSERIAL PRIMARY KEY,
    external_id TEXT,
    building_type TEXT,
    criticality SMALLINT NOT NULL DEFAULT 1 CHECK (criticality BETWEEN 1 AND 5),
    source_name TEXT NOT NULL DEFAULT 'OpenStreetMap',
    source_updated_at TIMESTAMPTZ,
    geom GEOMETRY(MULTIPOLYGON, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS infrastructure_buildings_geom_gix ON infrastructure_buildings USING GIST (geom);

CREATE TABLE IF NOT EXISTS population_cells (
    population_cell_id BIGSERIAL PRIMARY KEY,
    population_year SMALLINT NOT NULL,
    population_count NUMERIC(12, 3) NOT NULL CHECK (population_count >= 0),
    source_name TEXT NOT NULL DEFAULT 'WorldPop',
    source_version TEXT,
    geom GEOMETRY(POLYGON, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (population_year, source_name, geom)
);
CREATE INDEX IF NOT EXISTS population_cells_geom_gix ON population_cells USING GIST (geom);

CREATE TABLE IF NOT EXISTS emergency_facilities (
    facility_id BIGSERIAL PRIMARY KEY,
    external_facility_id TEXT UNIQUE,
    facility_name TEXT NOT NULL,
    facility_type TEXT NOT NULL CHECK (facility_type IN ('shelter', 'relief_camp', 'medical_facility', 'supply_depot', 'evacuation_pickup_point')),
    district_name TEXT,
    capacity_total INTEGER CHECK (capacity_total IS NULL OR capacity_total >= 0),
    capacity_available INTEGER CHECK (capacity_available IS NULL OR capacity_available >= 0),
    operational_status TEXT NOT NULL DEFAULT 'unknown' CHECK (operational_status IN ('proposed', 'verified_available', 'verified_full', 'temporarily_closed', 'unknown')),
    source_authority TEXT NOT NULL,
    source_reference TEXT,
    last_verified_at TIMESTAMPTZ NOT NULL,
    geom GEOMETRY(POINT, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (capacity_available IS NULL OR capacity_total IS NULL OR capacity_available <= capacity_total)
);
CREATE INDEX IF NOT EXISTS emergency_facilities_geom_gix ON emergency_facilities USING GIST (geom);
CREATE INDEX IF NOT EXISTS emergency_facilities_status_ix ON emergency_facilities (operational_status, last_verified_at DESC);

CREATE TABLE IF NOT EXISTS flood_extents (
    flood_extent_id BIGSERIAL PRIMARY KEY,
    event_id TEXT,
    inferred_at TIMESTAMPTZ NOT NULL,
    observed_from TIMESTAMPTZ,
    observed_to TIMESTAMPTZ,
    model_name TEXT NOT NULL DEFAULT 'U-Net',
    model_version TEXT NOT NULL,
    threshold_probability NUMERIC(4, 3) CHECK (threshold_probability BETWEEN 0 AND 1),
    confidence_score NUMERIC(4, 3) CHECK (confidence_score BETWEEN 0 AND 1),
    validation_status TEXT NOT NULL DEFAULT 'unreviewed' CHECK (validation_status IN ('unreviewed', 'analyst_verified', 'rejected')),
    source_scene_ids TEXT[] NOT NULL,
    geom GEOMETRY(MULTIPOLYGON, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS flood_extents_geom_gix ON flood_extents USING GIST (geom);
CREATE INDEX IF NOT EXISTS flood_extents_time_ix ON flood_extents (inferred_at DESC);

CREATE TABLE IF NOT EXISTS risk_cells (
    risk_cell_id BIGSERIAL PRIMARY KEY,
    assessment_time TIMESTAMPTZ NOT NULL,
    hazard_score NUMERIC(5, 2) NOT NULL CHECK (hazard_score BETWEEN 0 AND 100),
    exposure_score NUMERIC(5, 2) NOT NULL CHECK (exposure_score BETWEEN 0 AND 100),
    vulnerability_score NUMERIC(5, 2) NOT NULL DEFAULT 100 CHECK (vulnerability_score BETWEEN 0 AND 100),
    risk_score NUMERIC(5, 2) NOT NULL CHECK (risk_score BETWEEN 0 AND 100),
    risk_level TEXT NOT NULL CHECK (risk_level IN ('low', 'moderate', 'high', 'very_high')),
    population_affected_estimate NUMERIC(12, 2) DEFAULT 0 CHECK (population_affected_estimate >= 0),
    flood_extent_id BIGINT REFERENCES flood_extents(flood_extent_id),
    method_version TEXT NOT NULL,
    geom GEOMETRY(POLYGON, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS risk_cells_geom_gix ON risk_cells USING GIST (geom);
CREATE INDEX IF NOT EXISTS risk_cells_time_level_ix ON risk_cells (assessment_time DESC, risk_level);

-- Aggregates population and building exposure within the latest verified flood map.
CREATE OR REPLACE VIEW latest_verified_flood_exposure AS
WITH latest_extent AS (
    SELECT flood_extent_id, inferred_at, geom
    FROM flood_extents
    WHERE validation_status = 'analyst_verified'
    ORDER BY inferred_at DESC
    LIMIT 1
), population AS (
    SELECT le.flood_extent_id,
           COALESCE(SUM(p.population_count * ST_Area(ST_Intersection(p.geom, le.geom)::geography) / NULLIF(ST_Area(p.geom::geography), 0)), 0) AS affected_population_estimate
    FROM latest_extent le
    LEFT JOIN population_cells p ON ST_Intersects(p.geom, le.geom)
    GROUP BY le.flood_extent_id
), buildings AS (
    SELECT le.flood_extent_id,
           COUNT(b.building_id) AS affected_building_count,
           COALESCE(SUM(b.criticality), 0) AS criticality_sum
    FROM latest_extent le
    LEFT JOIN infrastructure_buildings b ON ST_Intersects(b.geom, le.geom)
    GROUP BY le.flood_extent_id
)
SELECT le.flood_extent_id,
       le.inferred_at,
       p.affected_population_estimate,
       b.affected_building_count,
       b.criticality_sum
FROM latest_extent le
JOIN population p ON p.flood_extent_id = le.flood_extent_id
JOIN buildings b ON b.flood_extent_id = le.flood_extent_id;

COMMIT;

-- Suggested normalized scoring policy, implemented by the application layer:
-- risk_score = 0.60 * hazard_score + 0.40 * exposure_score
-- Hazard score combines forecast exceedance, 24/48/72-hour rain and U-Net flood probability.
-- Exposure score combines affected population, critical-building presence and road isolation.
-- Do not trigger automated evacuation messages without an authorized operational review.
